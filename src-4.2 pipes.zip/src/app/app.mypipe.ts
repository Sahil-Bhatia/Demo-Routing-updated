import { PipeTransform, Pipe } from "@angular/core";

@Pipe({
    name:'searchpipe'
})



export class MyPipe implements PipeTransform{
    transform(value: any[], searchValue:any,searchType:any) {
        if(!searchValue) return value;
        if(searchType=='id'){
        return value.filter(data=>{
            return data.id.toString().toLowerCase().includes(searchValue.toLowerCase())
        })}
        if(searchType=='title'){
            return value.filter(data=>{
                return data.title.toString().toLowerCase().includes(searchValue.toLowerCase())
            }) 
        }
        if(searchType=='year'){
            return value.filter(data=>{
                return data.year.toString().toLowerCase().includes(searchValue.toLowerCase())
            }) 
        }
        if(searchType=='author'){
            return value.filter(data=>{
                return data.author.toString().toLowerCase().includes(searchValue.toLowerCase())
            }) 
        }
    }
    
}