import { Component } from "@angular/core";
import { Router } from "@angular/router";


@Component({
    selector:"login-comp",
    templateUrl:"app.login.html"
})


export class LoginComponent{
    username:string;
    password:string;
    check:boolean=false;
    constructor(private router:Router)
    {

    }
    authentication(){
        if(this.username=="Admin" && this.password=="Admin123" ){
            this.router.navigate(['welcome',this.username]); 
        }
        else{
            this.check=true;
        }
    }
    dismiss(){
        this.check=false;
    }
}