import { Component, OnInit } from "@angular/core";
import { ActivatedRoute,Params } from "@angular/router";


@Component({
    selector:"wel-comp",
    templateUrl:'app.welcome.html'
})



export class WelcomeComponent {
    username: any;
  


    constructor(private _active:ActivatedRoute){}
    
    ngOnInit(){
        this.username=this._active.snapshot.params['username'];  
    }
        
    
      
       
}